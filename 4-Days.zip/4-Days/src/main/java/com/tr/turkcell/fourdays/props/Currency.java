package com.tr.turkcell.fourdays.props;

public class Currency {
	
	private String Isim;
	private String ForexBuying;
	private String ForexSelling;
	
	public String getIsim() {
		return Isim;
	}
	public void setIsim(String isim) {
		Isim = isim;
	}
	public String getForexBuying() {
		return ForexBuying;
	}
	public void setForexBuying(String forexBuying) {
		ForexBuying = forexBuying;
	}
	public String getForexSelling() {
		return ForexSelling;
	}
	public void setForexSelling(String forexSelling) {
		ForexSelling = forexSelling;
	}
	
	
	

}
