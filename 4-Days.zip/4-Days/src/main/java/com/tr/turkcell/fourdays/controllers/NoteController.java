package com.tr.turkcell.fourdays.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.tr.turkcell.fourdays.model.Note;
import com.tr.turkcell.fourdays.repositories.NoteRepository;

@Controller
public class NoteController {
	
	@Autowired NoteRepository noteRepository;
	
	@GetMapping("/insertNote")
	public String insertNote() {
		
		Note nt = new Note();
		nt.setTitle("New Title");
		nt.setInfo("New Info");
		
		noteRepository.save(nt);
		
		return "note";
	}

}
