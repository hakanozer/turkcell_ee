package com.tr.turkcell.fourdays.restcontroller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tr.turkcell.fourdays.model.Note;
import com.tr.turkcell.fourdays.repositories.NoteRepository;

@RestController
public class NoteRestController {
	
	@Autowired NoteRepository noteRepository;
	
	// Note insert
	@PostMapping("/noteInsert")
	// @RequestBody Note note 
	public Map<String, Object> noteInsert( Note note ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		hm.put("statu", true);
		hm.put("message", "insert Success");
		hm.put("note", noteRepository.save(note));
	
		return hm;
	}
	
	
	@GetMapping("/allNote")
	public Map<String, Object> allNote() {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("allNote", noteRepository.findAll());
		return hm;
	}
	
	
	@GetMapping("/singleNote")
	public Map<String, Object> singleNote( int nid ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("singleNote", noteRepository.findById(nid));
		return hm;
	}
	
	
	@DeleteMapping("/deleteNote")
	public Map<String, Object> deleteNote( int nid ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		noteRepository.deleteById(nid);
		hm.put("deleteNote", true);
		return hm;
	}
	
	
	@PutMapping("/updateNote")
	public Map<String, Object> updateNote( Note note ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		Note nt = noteRepository.getOne(note.getNid());
		nt.setTitle(note.getTitle());
		nt.setInfo(note.getInfo());
		
		noteRepository.saveAndFlush(nt);
		
		return hm;
	}
	

	
	@GetMapping("/titleSearch")
	public Map<String, Object> fncTitleSearch( String title ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("titleSearch", noteRepository.titleSearch(title));
		return hm;
	}
	
	
	
}
