package com.tr.turkcell.fourdays.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.tr.turkcell.fourdays.model.Bilgiler;
import com.tr.turkcell.fourdays.model.JsonData;
import com.tr.turkcell.fourdays.model.Product;
import com.tr.turkcell.fourdays.props.Currency;
import com.tr.turkcell.fourdays.props.User;

@Controller
public class HomeController {
	
	@Autowired Connection db;
	
	@GetMapping("")
	public String register(Model model) {
		model.addAttribute("cls", xmlResult());
		model.addAttribute("ls", allProduct());
		model.addAttribute("validUser", new User());
		return "home";
	}
	
	
	/*
	@PostMapping("/userRegister")
	public String fncRegister( @RequestParam String uname, @RequestParam String mail, Model model ) {
		System.out.println(uname + " " + mail);
		model.addAttribute("uname", uname);
		return "home";
	}
	*/
	
	
	@PostMapping("/userRegister")
	public String userRegister( @Valid @ModelAttribute("validUser") User us, BindingResult bind ) {
		if(bind.hasErrors()) {
			// hata var
			System.out.println("Hata var");
		}else {
			// hata yok
			System.out.println("Hata yok, Gönderilebilir.");
		}
		return "home";
	}
	
	
	
	public void insertEmplye( User us ) {
		try {
			String query = "insert into INFORMATION_SCHEMA.TBL_EMPLOYEES values (null,?,?,?) ";
			PreparedStatement pre = db.prepareStatement(query);
			pre.setString(1, us.getMail());
			pre.setString(2, us.getUname());
			pre.setString(3, "Bilmem");
			pre.executeUpdate();
			db.close();
		} catch (Exception e) {
			System.err.println("insert err : " + e);
		}
		
	}

	
	
	public List<Bilgiler> allProduct() {
		
		String url = "https://jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
		Map<String, String> params = new HashMap<String, String>();
		params.put("ref", "5380f5dbcc3b1021f93ab24c3a1aac24");
		params.put("start", "0");
		
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> dt = restTemplate.getForEntity(url, String.class, params);
		
		Gson gson = new Gson();
		JsonData jd = gson.fromJson(dt.getBody(), JsonData.class);
		List<Product> pls = jd.getProducts();
		List<Bilgiler> ls = pls.get(0).getBilgiler();
		
		return ls;
		
	}
	
	
	public List<Currency> xmlResult() {
		
		List<Currency> cls = new ArrayList<>();
		
		try {
			String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
			String data = Jsoup.connect(url).ignoreContentType(true).timeout(30000).get().toString();
			Document doc = Jsoup.parse(data, "", Parser.xmlParser());
			Elements elements = doc.getElementsByTag("Currency");
			for( Element item : elements ) {
				String Isim = item.getElementsByTag("Isim").text();
				String ForexBuying = item.getElementsByTag("ForexBuying").text();
				String ForexSelling = item.getElementsByTag("ForexSelling").text();
				
				Currency c = new Currency();
				c.setIsim(Isim);
				c.setForexBuying(ForexBuying);
				c.setForexSelling(ForexSelling);
				
				cls.add(c);
				
			}
		} catch (Exception e) {
			System.err.println("xml Error : " + e);
		}
		
		return cls;
	}
	
	
	
	
}
