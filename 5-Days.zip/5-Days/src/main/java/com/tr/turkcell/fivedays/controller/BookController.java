package com.tr.turkcell.fivedays.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tr.turkcell.fivedays.soapclient.SoapClient;

import https.www_java2blog_com.xml.book.GetBookRequest;
import https.www_java2blog_com.xml.book.GetBookResponse;

@RestController
public class BookController {
	
	
	@Autowired SoapClient soapClient;
	
	@PostMapping("/soapFindItem")
	public GetBookResponse findItem( GetBookRequest req ) {
		GetBookResponse res = soapClient.getItem(req);
		return res;
	}
	

}
