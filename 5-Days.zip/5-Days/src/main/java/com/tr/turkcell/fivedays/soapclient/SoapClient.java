package com.tr.turkcell.fivedays.soapclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import https.www_java2blog_com.xml.book.GetBookRequest;
import https.www_java2blog_com.xml.book.GetBookResponse;

@Service
public class SoapClient {
	
	@Autowired Jaxb2Marshaller jaxb2Marshaller;
	private WebServiceTemplate webServiceTemplate;
	
	public GetBookResponse getItem( GetBookRequest req ) {
		webServiceTemplate = new WebServiceTemplate(jaxb2Marshaller);
		GetBookResponse response = (GetBookResponse) webServiceTemplate.marshalSendAndReceive("http://localhost:8080/ws", req);
		return response;
	}
	
	

}
