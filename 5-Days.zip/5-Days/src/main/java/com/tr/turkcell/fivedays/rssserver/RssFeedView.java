package com.tr.turkcell.fivedays.rssserver;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.feed.AbstractRssFeedView;

import com.rometools.rome.feed.rss.Channel;
import com.rometools.rome.feed.rss.Content;
import com.rometools.rome.feed.rss.Item;

@Component
public class RssFeedView extends AbstractRssFeedView {

	@Override
	protected void buildFeedMetadata(Map<String, Object> model, Channel feed, HttpServletRequest request) {
		feed.setTitle("Word Rss Title");
		feed.setDescription("Word Rss Desc");
		feed.setLink("http://google.com.tr");
	}
	
	@Override
	protected List<Item> buildFeedItems(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Item> ls = new ArrayList<Item>();
		
		Item i1 = new Item();
		i1.setTitle("Product -1");
		i1.setLink("http://localhost/pro/1");
		i1.setPubDate(new Date());
		Content cn1 = new Content();
		cn1.setType("Type");
		cn1.setValue("Type Val");
		i1.setContent(cn1);
		
		
		Item i2 = new Item();
		i2.setTitle("Product -2");
		i2.setLink("http://localhost/pro/2");
		i2.setPubDate(new Date());
		Content cn2 = new Content();
		cn2.setType("Type");
		cn2.setValue("Type Val");
		i2.setContent(cn2);
		
		ls.add(i1);
		ls.add(i2);
		
		return ls;
	}

	
	
	
}
