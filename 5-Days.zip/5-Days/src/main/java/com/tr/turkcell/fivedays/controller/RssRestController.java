package com.tr.turkcell.fivedays.controller;

import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.View;

import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.io.XmlReader;
import com.tr.turkcell.fivedays.rssserver.RssFeedView;

@RestController
public class RssRestController {
	
	
	@Autowired RssFeedView view;
	
	@GetMapping("/getAllFeed")
	public View getAllFeed() {
		return view;
	}
	
	
	// client rss read
	@GetMapping("/readAllFeed")
	public Map<String, Object> readAllFeed() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("rssReadAll", rssReadFnc());
		return hm;
	}
	
	
	private SyndFeed rssReadFnc() {
		String url = "http://localhost:8080/getAllFeed";
		try ( XmlReader reader = new XmlReader(new URL(url)) ) {
			SyndFeed syndFeed = new SyndFeedInput().build(reader);
			System.out.println(syndFeed.getTitle());
			
			for( SyndEntry enrty : syndFeed.getEntries() ) {
				System.out.println("Title : " + enrty.getTitle());
				System.out.println("Link : " + enrty.getLink());
			}
			
			return syndFeed;
			
		} catch (Exception e) {
			System.err.println("Rss Error : " + e);
		}
		return null;
	}
	

}
