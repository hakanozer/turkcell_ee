package useServlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String mail = req.getParameter("mail");
		String pass = req.getParameter("pass");
		
		if (mail.equals("ali@ali.com") && pass.equals("12345")) {
			// login success
			resp.sendRedirect("dashboard.jsp");
		}else {
			resp.sendRedirect("index.jsp?failLogin=fail");
		}
		System.out.println(mail + " " + pass );
	}
	
	
	

}
