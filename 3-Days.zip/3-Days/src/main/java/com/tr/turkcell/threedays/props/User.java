package com.tr.turkcell.threedays.props;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class User {
	
	
	@NotEmpty(message = "Name Not @NotEmpty ")
	private String uname;
	
	@Email(message = "Mail format fail!")
	private String mail;
	
	@Min( value = 18, message = "Age min 18")
	private int age;

	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	

}
