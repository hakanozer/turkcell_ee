package com.tr.turkcell.threedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tr.turkcell.threedays.props.User;

@Controller
public class HomeController {
	
	@GetMapping("")
	public String fncHome() {
		return "home";
	}
	
	/*
	@PostMapping("/userRegister")
	public String fncRegister( @RequestParam String uname, @RequestParam String mail, Model model ) {
		System.out.println(uname + " " + mail);
		model.addAttribute("uname", uname);
		return "home";
	}
	*/
	
	
	@PostMapping("/userRegister")
	public String fncRegister( User us , Model model ) {
		System.out.println(us.getUname() + " " + us.getMail());
		model.addAttribute("uname", us.getUname());
		return "home";
	}

	
}
