package com.tr.turkcell.threedays.controllers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tr.turkcell.threedays.props.User;

@Controller
public class HomeController {
	
	@Autowired Connection db;
	
	@GetMapping("")
	public String register(Model model) {
		model.addAttribute("validUser", new User());
		return "home";
	}
	
	
	/*
	@PostMapping("/userRegister")
	public String fncRegister( @RequestParam String uname, @RequestParam String mail, Model model ) {
		System.out.println(uname + " " + mail);
		model.addAttribute("uname", uname);
		return "home";
	}
	*/
	
	
	@PostMapping("/userRegister")
	public String userRegister( @Valid @ModelAttribute("validUser") User us, BindingResult bind ) {
		if(bind.hasErrors()) {
			// hata var
			System.out.println("Hata var");
		}else {
			// hata yok
			System.out.println("Hata yok, Gönderilebilir.");
		}
		return "home";
	}
	
	
	
	public void insertEmplye( User us ) {
		try {
			String query = "insert into INFORMATION_SCHEMA.TBL_EMPLOYEES values (null,?,?,?) ";
			PreparedStatement pre = db.prepareStatement(query);
			pre.setString(1, us.getMail());
			pre.setString(2, us.getUname());
			pre.setString(3, "Bilmem");
			pre.executeUpdate();
			db.close();
		} catch (Exception e) {
			System.err.println("insert err : " + e);
		}
		
	}

	
}
