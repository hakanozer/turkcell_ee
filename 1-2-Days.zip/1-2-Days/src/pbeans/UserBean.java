package pbeans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class UserBean {

	public String formTitle = "User Login";
	public String name;
	public String mail;
	public int age;
	
	public String redirectFnc() {
		return "dashboard?faces-redirect=true";
	}
	
	
	public String loginAction() {
		
		System.out.println( name + " " + mail + " " + age );
		return "";
	}

	public String getFormTitle() {
		return formTitle;
	}

	public void setFormTitle(String formTitle) {
		this.formTitle = formTitle;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
	
}
