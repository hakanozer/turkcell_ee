package pbeans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class CustomerBean {
	
	public CustomerBean() {
		System.out.println("CustomerBean call");
		allCustomer();
	}

	private List<Customer> cls = new ArrayList<>();
	
	// @PostConstruct
	public void allCustomer() {
		cls.clear();
		for (int i = 0; i < 10; i++) {
			Customer cs = new Customer();
			cs.setId(i);
			cs.setName("Ali " +i);
			cs.setSurname("Bilmem " +i);
			cs.setMail("ali@ali.com"+i);
			cls.add(cs);
		}
	}
	
	
	public void deleteItem( int id ) {
		System.out.println("id : " + id);
		cls.remove(id);
	}


	public List<Customer> getCls() {
		return cls;
	}


	public void setCls(List<Customer> cls) {
		this.cls = cls;
	}
	
	
	
}
