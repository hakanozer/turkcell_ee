
package pkg2.days;

import java.util.List;
import model.TblEmployees;


public class Days {

    
    public static void main(String[] args) {
        
        EmployeModel model = new EmployeModel();
        int statu = model.newEmploye("Mehmet", "Bilsin", "mehmeh@mail.com");
        System.out.println("Statu : " + statu);
        
        // all employes result
        /*
        List<TblEmployees> ls = model.allEmploye();
        for ( TblEmployees item : ls ) {
            System.out.println("Name : " + item.getFirstName() );
        }
        */
        
        // model.employeUpdate(1, "Ali");
        
        //model.employeDeleteItem(8);
        
    }
    
}
