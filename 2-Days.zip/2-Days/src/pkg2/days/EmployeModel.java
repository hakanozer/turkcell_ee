
package pkg2.days;

import java.util.List;
import model.TblEmployees;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class EmployeModel {
    
    
    SessionFactory sf = NewHibernateUtil.getSessionFactory();
    
    
    // new employe insert
    public int newEmploye( String first_name, String last_name, String email ) {
        int statu = -1;
        
        Session sesi = sf.openSession();
        Transaction tr = sesi.beginTransaction();
        
        TblEmployees em = new TblEmployees();
        em.setFirstName(first_name);
        em.setLastName(last_name);
        em.setEmail(email);
        
        statu = (int) sesi.save(em);
        tr.commit();
        sesi.close();
        sf.close();
        
        return statu;
    }
    
    
    
    public List<TblEmployees> allEmploye() {
        
        Session sesi = sf.openSession();
        List<TblEmployees> ls = sesi.createQuery(" from TblEmployees ").list();
        sesi.close();
        sf.close();
        return ls;
        
    }
    
    
    
    
    public void employeUpdate( int eid, String first_name) {
        
        Session sesi = sf.openSession();
        Transaction tr = sesi.beginTransaction();
        
        TblEmployees em = (TblEmployees) sesi.load(TblEmployees.class, eid);
        em.setFirstName(first_name);
        
        sesi.update(em);
        tr.commit();
        
        sesi.close();
        sf.close();
        
    }
    
    
    // employes item delete
    public void employeDeleteItem ( int eid ) {
        
        Session sesi = sf.openSession();
        Transaction tr = sesi.beginTransaction();
        
        TblEmployees em = (TblEmployees) sesi.load(TblEmployees.class, eid);
        
        sesi.delete(em);
        tr.commit();
        
        sesi.close();
        sf.close();
        
    }
    
    
    
    
}
