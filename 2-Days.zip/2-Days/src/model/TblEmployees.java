/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author hakan
 */
@Entity
@Table(name = "TBL_EMPLOYEES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TblEmployees.findAll", query = "SELECT t FROM TblEmployees t")
    , @NamedQuery(name = "TblEmployees.findByEid", query = "SELECT t FROM TblEmployees t WHERE t.eid = :eid")
    , @NamedQuery(name = "TblEmployees.findByFirstName", query = "SELECT t FROM TblEmployees t WHERE t.firstName = :firstName")
    , @NamedQuery(name = "TblEmployees.findByLastName", query = "SELECT t FROM TblEmployees t WHERE t.lastName = :lastName")
    , @NamedQuery(name = "TblEmployees.findByEmail", query = "SELECT t FROM TblEmployees t WHERE t.email = :email")})
public class TblEmployees implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "EID")
    private Integer eid;
    @Basic(optional = false)
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "EMAIL")
    private String email;

    public TblEmployees() {
    }

    public TblEmployees(Integer eid) {
        this.eid = eid;
    }

    public TblEmployees(Integer eid, String firstName, String lastName) {
        this.eid = eid;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (eid != null ? eid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TblEmployees)) {
            return false;
        }
        TblEmployees other = (TblEmployees) object;
        if ((this.eid == null && other.eid != null) || (this.eid != null && !this.eid.equals(other.eid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.TblEmployees[ eid=" + eid + " ]";
    }
    
}
