
package useThread;

public class UserThread implements Runnable {
    
    String imagePath = "";

    public UserThread(String imagePath) {
        this.imagePath = imagePath;
    }
    
   

    @Override
    public void run() {
        //int i = 1 / 0;
        for( int i = 0; i<50 ;i++) {
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            System.out.println("for call : " + imagePath );
        }
    }
    
    
    
}
